#include "syscall.h"
#include "copyright.h"
int main() {
	int a;
	PrintString("Nhap so nguyen: ");
	a = ReadInt();
	if(a != 0)
	   PrintInt(a);

	Halt();
}
