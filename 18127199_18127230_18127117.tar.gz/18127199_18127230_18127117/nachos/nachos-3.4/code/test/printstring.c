#include"syscall.h"
#include"copyright.h"

int main() {
	char* a;
	PrintString("Nhap chuoi: ");
	ReadString(a, 15);	
	PrintString("Chuoi vua nhap: ");
	PrintString(a);
	Halt();
}
