#include "syscall.h"
#include "copyright.h"
int main()
{
	int number = 9999;
   
	PrintInt(number);		

	Halt();
}
