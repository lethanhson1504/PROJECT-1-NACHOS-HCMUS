#include "syscall.h"
#include "copyright.h"

int main() {
	PrintString("---------------Gioi thieu ve Do an Nachos - Mon hoc: HE DIEU HANH-------------\n");
	PrintString(">>Danh sach thanh vien<<\n@Le Thanh Son\t\t18127199\n@Nguyen Ba Tin\t\t18127230\n@Truong Phuc Khang\t18127117\n\n");
	PrintString(">>Gioi thieu ve chuong trinh sort<<\n #Nguoi dung nhap vao so nguyen n tu 1 - 100\n #Nguoi dung nhap mang n so nguyen\n #Chuong trinh xuat ra mang so nguyen vua nhap\n #Sau do hoi nguoi dung muon sap xep cac so nguyen theo thu tu tang dan hay giam dan\n #Chuong trinh sap xep lai va xuat ra mang so nguyen sau khi da sap xep.\n\n");
	PrintString(">>Gioi thieu chuong trinh in ra cac ki tu ascii<<\n #Chuong trinh in ra cac ki tu doc duoc cua bang ma ascii tu 33 - 126\n");
	Halt();	
}
