#include "syscall.h"
#include "copyright.h"

int main(){
	//nhap n
	int a[100]; //khai bao mang co 100 phan tu
	int n, i, c = 1, ascending;
	do {
		PrintString("Nhap n(n <= 100): ");
		n = ReadInt();
	}
	while(n > 100 || n < 1);

		
	//nhap mang
	
	for(i = 0; i < n; i++) {
		PrintString("a[");
		PrintInt(i);
		PrintString("] = ");
		a[i] = ReadInt(); 	
		PrintString("\n");
	}

	PrintString("Mang truoc khi xep: \n\n");
	//xuat mang truoc khi sap xep
	for(i = 0; i < n; i++) {
		PrintInt(a[i]); 	
		PrintString("  ");
	}
	
	PrintString("\nSap xep mang tang dan hay giam dan(1: tang dan, 0: giam dan): ");
	ascending = ReadInt();
	//sap xep mang voi bubble sort
	while(c) {
		c = 0;
		i = 0;
		for(i; i < n - 1; i++) {
			if (ascending == 1) {
				if (a[i] > a[i + 1]) {
					int temp = a[i];
					a[i] = a[i + 1];
					a[i + 1] = temp;
					c = 1;
				}
			}
			else {
				if (a[i] < a[i + 1]) {
					int temp = a[i];
					a[i] = a[i + 1];
					a[i + 1] = temp;
					c = 1;
				}
			}
		}
	}
	
	PrintString("\nMang sau khi xep: \n");
	//xuat mang sau khi sap xep
	for(i = 0; i < n; i++) {
		PrintInt(a[i]); 	
		PrintString("  ");
	}	

	Halt();
}
