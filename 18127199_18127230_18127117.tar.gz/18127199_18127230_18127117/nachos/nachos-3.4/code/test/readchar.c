#include "syscall.h"
#include "copyright.h"

int main() {
	char a;
	PrintString("Nhap ki tu: ");
	a = ReadChar();
	if (a != 0)
	{
		PrintString("Ki tu vua nhap: ");
		PrintChar(a);		
	}
	
	Halt();
}
