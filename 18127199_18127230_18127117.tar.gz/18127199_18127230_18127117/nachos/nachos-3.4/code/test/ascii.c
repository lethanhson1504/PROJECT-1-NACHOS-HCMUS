#include "syscall.h"
#include "copyright.h"

int main() {
	int i;
	PrintString("Cac ki tu doc duoc cua bang ma ascii : \n");
	for(i = 33 ; i < 127; i++){
		PrintInt(i);
		PrintString("\t");
		PrintChar(i);		
		PrintString("\n");	
	}	
	Halt();
}
