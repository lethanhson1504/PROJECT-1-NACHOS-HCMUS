// exception.cc 
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.  
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "syscall.h"

//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2. 
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!
//
//	"which" is the kind of exception.  The list of possible exceptions 
//	are in machine.h.
//----------------------------------------------------------------------
#define MaxFileLength 32
void IncreasePC()
{
	int counter = machine->ReadRegister(PCReg);
   	machine->WriteRegister(PrevPCReg, counter);
    	counter = machine->ReadRegister(NextPCReg);
    	machine->WriteRegister(PCReg, counter);
   	machine->WriteRegister(NextPCReg, counter + 4);
}

char* User2System(int virtAddr, int limit)
{
	int i; //chi so index
	int oneChar;
	char* kernelBuf = NULL;
	kernelBuf = new char[limit + 1]; //can cho chuoi terminal
	if (kernelBuf == NULL)
		return kernelBuf;
		
	memset(kernelBuf, 0, limit + 1);
	
	for (i = 0; i < limit; i++)
	{
		machine->ReadMem(virtAddr + i, 1, &oneChar);
		kernelBuf[i] = (char)oneChar;
		if (oneChar == 0)
			break;
	}
	return kernelBuf;
}

int System2User(int virtAddr, int len, char* buffer)
{
	if (len < 0) return -1;
	if (len == 0)return len;
	int i = 0;
	int oneChar = 0;
	do{
		oneChar = (int)buffer[i];
		machine->WriteMem(virtAddr + i, 1, oneChar);
		i++;
	} while (i < len && oneChar != 0);
	return i;
}

int pow(int a){
	int kq = 1;
	for(int i = 0; i < a; i++){
		kq *= 10;
	}
	return kq;
}
void
ExceptionHandler(ExceptionType which)
{
    int type = machine->ReadRegister(2);

    switch (which) {
	case NoException:
		return;

	case PageFaultException:
		printf("\n\n No valid translation found");
		interrupt->Halt();
		break;

	case ReadOnlyException:
		printf("\n\n Write attempted to page marked read-only");
		interrupt->Halt();
		break;

	case BusErrorException:
		printf("\n\n Translation resulted invalid physical address");
		interrupt->Halt();
		break;

	case AddressErrorException:
		printf("\n\n Unaligned reference or one that was beyond the end of the address space");
		interrupt->Halt();
		break;

	case OverflowException:
		printf("\n\n Integer overflow in add or sub.");
		interrupt->Halt();
		break;

	case IllegalInstrException:		
		printf("\n\n Unimplemented or reserved instr.");
		interrupt->Halt();
		break;

	case NumExceptionTypes:
		printf("\n\n Number exception types");
		interrupt->Halt();
		break;

	case SyscallException:
		switch (type){	
		case SC_Halt: {
			// Input: Khong co
			// Output: Thong bao tat may
			// Chuc nang: Tat HDH
			DEBUG('a', "\nShutdown, initiated by user program. ");
			printf("\nShutdown, initiated by user program. ");
			interrupt->Halt();
			break;
		}
		case SC_PrintString:
		{
			int diaChi;		
			diaChi = machine->ReadRegister(4); // Lay dia chi cua tham so buffer tu thanh ghi so 4

			char* buffer;
			buffer = User2System(diaChi, 1024); //con tro buffer nhan chuoi tra ve tu ham User2System

			gSynchConsole->Write(buffer, 1024); // Goi ham Write cua SynchConsole de in chuoi
			delete[] buffer; 
			IncreasePC(); // Tang Program Counter de tranh bi loop forever
			return;
			break;
		}
		case SC_ReadInt:
		{
                    char* soNguyen;     //tao con tro soNguyen kieu char

                    soNguyen = new char[256];   //cap phat cho con tro soNguyen 15 byte
                    int n = gSynchConsole->Read(soNguyen, 256); //dung con tro gsynchcconsole doc chuoi so vao soNguyen, n nhan so ki tu doc dc
			

		                                  
                    int index = 0; //duyet mang tu vi tri thu 0
  		    int dau = 1; //bien luu dau cua so nguyen
                    if(soNguyen[0] == '-') {//Kiem tra so am hay duong, neu ki tu dau cua mang la "-" thi co nghia la so am
                        index = 1;  //duyet mang tu vi tri thu 1
			dau = -1;
		    }
                    
                    // Kiem tra tinh hop le cua chuoi so nguyen
                    for(int i = index; i < n; i++)					
                    {
                        if(soNguyen[i] == '.') //Neu trong so nguyen co ki tu "." thi tat ca so phia sau phai la 0
                        {              
                            for(int j = i + 1; j < n; j++) //chay for de kiem tra tat ca so sau dau "."
                            {
				// So khong hop le
                                if(soNguyen[j] != '0') //neu ko phai ki tu'0'
                                {    
				    printf("Khong phai la so nguyen!");            
                                    machine->WriteRegister(2, 0);  //tra ve thanh ghi so 2 gia tri 0
                                    IncreasePC();  //tang program counter len 4
                                    delete[] soNguyen; //xoa cap phat dong mang char
                                    return;
                                }
                            }             
			    soNguyen[i] = NULL;     //la so nguyen nen cat di ".000" phia sau chuoi    9.000 -> 9   
                        }
                        else if(soNguyen[i] < '0' || soNguyen[i] > '9') //neu tung ki tu cua so nguyen ! [0;9], tra ve 0
                        {
			    printf("Khong duoc nhap ki tu!");
                            machine->WriteRegister(2, 0);
                            IncreasePC(); //tang program counter len 4
                            delete[] soNguyen; //xoa cap phat dong mang char
                            return;
                        }
                    }	

		    if(soNguyen[0] == '-') {
		    	 if(n - 1 > 10) { //neu so do dai so nguyen - 1 > 10, nghia la < -2,147,483,647
				 printf("Vuot qua pham vi bien int trong c");
				 machine->WriteRegister(2, 0);  //tra ve thanh ghi so 2 gia tri 0
				 IncreasePC();  //tang program counter len 4
				 delete[] soNguyen; //xoa cap phat dong mang char
				 return;
			 }
			 if(n - 1 == 10) {
			     	 if(soNguyen[1] > '2' || soNguyen[2] > '1' || soNguyen[3] > '4' || soNguyen[4] > '7' || soNguyen[5] > '4' || soNguyen[6] > '8' || soNguyen[7] > '3' || soNguyen[8] > '6' || soNguyen[9] > '4' || soNguyen[10] > '7'){
					 printf("Vuot qua pham vi bien int trong c");
					 machine->WriteRegister(2, 0);  //tra ve thanh ghi so 2 gia tri 0
					 IncreasePC();  //tang program counter len 4
					 delete[] soNguyen; //xoa cap phat dong mang char
					 return;
				} 
		    	 }
		    }
		    else if(n > 10) { //neu so do dai so nguyen > 10, nghia la > 2,147,483,648
			 printf("Vuot qua pham vi bien int trong c");
			 machine->WriteRegister(2, 0);  //tra ve thanh ghi so 2 gia tri 0
		         IncreasePC();  //tang program counter len 4
		         delete[] soNguyen; //xoa cap phat dong mang char
		         return;
		    }
	     	    
		    if(n == 10) { //neu so do dai so nguyen - 1 > 10, nghia la > 2,147,483,647
			  if(soNguyen[0] > '2' || soNguyen[1] > '1' || soNguyen[2] > '4' || soNguyen[3] > '7' || soNguyen[4] > '4' || soNguyen[5] > '8' || soNguyen[6] > '3' || soNguyen[7] > '6' || soNguyen[8] > '4' || soNguyen[9] > '7'){
				 printf("Vuot qua pham vi bien int trong c");
				 machine->WriteRegister(2, 0);  //tra ve thanh ghi so 2 gia tri 0
				 IncreasePC();  //tang program counter len 4
				 delete[] soNguyen; //xoa cap phat dong mang char
				 return;
			  }
		    }
	            //chuyen chuoi thanh so nguyen de tra ve ket qua

		    int KetQua = 0, soMu; //ketQua luu gia tri khi chuyen char* thanh int	   
		    if(dau == -1){
		    	soMu = strlen(soNguyen) - 2; //luu so mu, neu so am thi tru 2 vi ki tu dau la "-"
		    }
		    else soMu = strlen(soNguyen) - 1; 

		    for(unsigned int i = index; i < strlen(soNguyen); i++) //duyet tu vi tri index
		    {
			KetQua += int(soNguyen[i] - 48) * pow(soMu); //pow tra ve 10^x
			soMu--;
     		    }
		    KetQua *= dau;
		    machine->WriteRegister(2, KetQua);  //tra ve 1 neu la so nguyen
                    IncreasePC(); //tang pc de tranh bi loop forever
                    delete[] soNguyen; //xoa cap phat dong mang char
                    return;
		    break;		
		}

		case SC_ReadString:
		{
			char* chuoi = new char[1024];
			gSynchConsole->Read(chuoi, 1024); //doc chuoi ng dung nhap vao bien chuoi
			int len = machine->ReadRegister(5);// lay chieu dai chuoi tu thanh ghi so 5
			int diaChi = machine->ReadRegister(4); // lay dia chi cua bien mang can tra ket qua
			System2User(diaChi, len, chuoi); //copy chuoi user nhap vao dia chi cua bien ket qua
			IncreasePC(); // Tang Program Counter de tranh loop forever
			delete[] chuoi;
			return;
			break;
		}

		case SC_PrintInt:
		{
		    int number = machine->ReadRegister(4); //lay gia tri tu thanh ghi so 4
		    if(number == 0){ //neu so bang 0 thi in ra mh va ket thuc
			gSynchConsole->Write("0", 1);
			IncreasePC();
			return;
			break;
		    }

		    char* soNguyen = new char[15]; //cap phat mang ki tu songuyen de luu chuoi so in ra mh
		    int count = 0; //bien dem do dai so
		    if(number < 0){ //neu so am thi ki tu dau tien la dau "-"
			soNguyen[0] = '-';
			number *= -1; // chuyen thanh so duong de chuyen ve chuoi
			count = 1; // neu so am thi tang len 1
		    }

		    int temp = number;
		    while(temp > 0){ //dem do dai cua so nguyen
			count++;
			temp /= 10;
		    }
		    soNguyen[count] = NULL; //gan NULL de danh dau vi tri ket thuc cua chuoi

		    while(number > 0){
			int DonVi = number % 10;
			soNguyen[count - 1] = DonVi + 48; //gan tung ki tu hang don vi vao mang soNguyen
			count--;
			number /= 10;
		    }

		    gSynchConsole->Write(soNguyen, strlen(soNguyen)); //in ra man hinh chuoi voi tham so chieu dai cua chuoi
		    delete[] soNguyen;
		    IncreasePC(); //tang pc de tranh bi loop forever
		    return;
		    break;
		}

		case SC_ReadChar:
		{
		    
		    char* KiTu = new char[256]; //cap phat con tro mang char de nhan chuoi nguoi dung nhap
		    int n = gSynchConsole->Read(KiTu, 256); //bien n nhan so ki tu nguoi dung nhap, mang char KiTu nhan chuoi
		    
		    if(n == 0){ //neu nguoi dung khong nhap ma nhan enter
			printf("Khong duoc nhap ki tu rong!");
			machine->WriteRegister(2, 0); //tra ve thanh ghi so 2 ki tu NULL
			IncreasePC();
			return;
			break;
		    }


		    if(n > 1){ //chi duoc nhap 1 ki tu
			printf("Chi nhap dung 1 ki tu!");
			machine->WriteRegister(2, 0);  //tra ve thanh ghi so 2 ki tu NULL
			IncreasePC();
			return;
			break;
		    }
		    
		    machine->WriteRegister(2, KiTu[0]); //tra ve thanh ghi so 2 ki tu nguoi dung nhap dung
		    delete[] KiTu;
		    IncreasePC(); //tang program counter de tranh bi loop forever
		    return;
		    break;
		}
		case SC_PrintChar:
		{		    		 
		    char KiTu = machine->ReadRegister(4); //lay tham so truyen vao tu thanh ghi so 2
		    char* KQ = new char[2]; //tao mang char* voi 2 phan tu
		    KQ[0] = KiTu; //phan tu dau la ki tu tu thanh ghi 4
		    KQ[1] = NULL; //phan tu 2 la null
		    gSynchConsole->Write(KQ, 2); //in ki tu ra man hinh
		    delete[] KQ; //xoa cap phat dong
		    IncreasePC(); //tang program counter de tranh bi loop forever
		    return;
		    break;
		}
		case SC_Create:
		{
		int virtAddr;
		char* filename;
		DEBUG('a',"\n SC_Create call ...");
		DEBUG('a',"\n Reading virtual address of filename");
		// Lấy tham số tên tập tin từ thanh ghi r4
		virtAddr = machine->ReadRegister(4);
		DEBUG ('a',"\n Reading filename.");
		// MaxFileLength là = 32
		filename = User2System(virtAddr,MaxFileLength+1);
			if (filename == NULL)
			{
			printf("\n Not enough memory in system");
			DEBUG('a',"\n Not enough memory in system");
			machine->WriteRegister(2,-1); // trả về lỗi cho chương
			// trình người dùng
			delete filename;
			return;
			}
		DEBUG('a',"\n Finish reading filename.");
		//DEBUG(‘a’,"\n File name : '"<<filename<<"'");
		// Create file with size = 0
		// Dùng đối tượng fileSystem của lớp OpenFile để tạo file,
		// việc tạo file này là sử dụng các thủ tục tạo file của hệ điều
		// hành Linux, chúng ta không quản ly trực tiếp các block trên
		// đĩa cứng cấp phát cho file, việc quản ly các block của file
		// trên ổ đĩa là một đồ án khác
		   if (!fileSystem->Create(filename,0))
			{
			printf("\n Error create file '%s'",filename);
			machine->WriteRegister(2,-1);
			delete filename;
			return;
			}
		machine->WriteRegister(2,0); // trả về cho chương trình
		// người dùng thành công
		delete filename;
		break;
			}
		}
	}
}
